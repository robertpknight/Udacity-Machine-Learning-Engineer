from setuptools import setup

setup(name='gaus_bin_dists',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['gaus_bin_dists'],
      author = 'Robert Knight',
      author_email = 'robertpknight@hotmail.com',
      zip_safe=False)
