# Python package development

This repo holds the code for a package which can do some functions with
Gaussian and Binomial distribution classes.

It is a practice exercise that is part of the ML Engineer course.

It teachs some modularising code basics, and is an opportunity to load a
package to PyPi.
